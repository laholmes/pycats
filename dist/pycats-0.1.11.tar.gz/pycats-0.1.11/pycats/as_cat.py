def as_cat(x):
    return x.astype('category')