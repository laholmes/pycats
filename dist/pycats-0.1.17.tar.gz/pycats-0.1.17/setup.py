from setuptools import setup

setup(
    name='pycats',
    packages=['pycats'],
    version='0.1.17',
    description='tools for working with categories in pandas dataframes',
    url='https://github.com/laholmes/pycats',
    author='laurence holmes',
    author_email='laholmes@hotmail.co.uk'
)
