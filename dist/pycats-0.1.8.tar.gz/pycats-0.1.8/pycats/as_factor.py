def as_factor(x):
    return x.astype('category')