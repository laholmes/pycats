from setuptools import setup

setup(
    name='pycats',
    version='0.1.1',
    scripts=['lump.py'],
    description='tools for working with categories in pandas dataframes',
    url='https://github.com/laholmes/pycats',
    author='laurence holmes',
    author_email='laholmes@hotmail.co.uk'
)
